import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { updateEmailSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all emails with optional filters
  app.get("/api/emails", async (req, res) => {
    try {
      const { filter } = req.query;
      let filterOptions = {};
      
      if (filter === "unread") {
        filterOptions = { isRead: false, isArchived: false };
      } else if (filter === "starred") {
        filterOptions = { isStarred: true, isArchived: false };
      } else if (filter === "archived") {
        filterOptions = { isArchived: true };
      } else {
        filterOptions = { isArchived: false };
      }
      
      const emails = await storage.getEmails(filterOptions);
      res.json(emails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch emails" });
    }
  });

  // Get single email
  app.get("/api/emails/:id", async (req, res) => {
    try {
      const email = await storage.getEmail(req.params.id);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      res.json(email);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch email" });
    }
  });

  // Update email (star, read status, etc.)
  app.patch("/api/emails/:id", async (req, res) => {
    try {
      const updates = updateEmailSchema.parse(req.body);
      const updatedEmail = await storage.updateEmail(req.params.id, updates);
      
      if (!updatedEmail) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      res.json(updatedEmail);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid update data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update email" });
    }
  });

  // Delete email
  app.delete("/api/emails/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteEmail(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Email not found" });
      }
      res.json({ message: "Email deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete email" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
