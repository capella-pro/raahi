import { type User, type InsertUser, type Email, type InsertEmail, type UpdateEmail } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Email operations
  getEmails(filter?: { isRead?: boolean; isStarred?: boolean; isArchived?: boolean }): Promise<Email[]>;
  getEmail(id: string): Promise<Email | undefined>;
  createEmail(email: InsertEmail): Promise<Email>;
  updateEmail(id: string, updates: UpdateEmail): Promise<Email | undefined>;
  deleteEmail(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private emails: Map<string, Email>;

  constructor() {
    this.users = new Map();
    this.emails = new Map();
    
    // Initialize with sample emails
    this.initializeSampleEmails();
  }

  private initializeSampleEmails() {
    const sampleEmails: Email[] = [
      {
        id: "1",
        sender: "John Doe",
        senderEmail: "john.doe@company.com",
        subject: "Q4 Budget Review Meeting",
        snippet: "Hi team, I'd like to schedule our Q4 budget review meeting for next week. Please let me know your availability...",
        body: `Hi team,

I hope this email finds you well. I'd like to schedule our Q4 budget review meeting for next week to discuss our financial performance and plan for the upcoming quarter.

**Key topics to cover:**

• Q3 actual vs. projected spending
• Q4 budget allocations  
• Resource planning for 2024
• Department-specific budget requests

Please review the attached preliminary budget figures and come prepared with your department's specific needs and projections.

Could you please let me know your availability for the following time slots:

• Tuesday, Oct 15th - 2:00 PM - 4:00 PM
• Wednesday, Oct 16th - 10:00 AM - 12:00 PM
• Thursday, Oct 17th - 1:00 PM - 3:00 PM

I'll send out a calendar invite once we confirm the best time for everyone.

Best regards,
John`,
        timestamp: new Date(Date.now() - 2 * 60 * 1000),
        isRead: false,
        isStarred: false,
        isArchived: false,
        hasAttachment: true,
        labels: ["work"]
      },
      {
        id: "2", 
        sender: "Sarah Miller",
        senderEmail: "sarah.miller@agency.com",
        subject: "Weekly Design Review",
        snippet: "The design mockups look great! I have a few minor feedback points to share during our review...",
        body: `Hi there,

The design mockups look great! I have a few minor feedback points to share during our review.

Overall, the direction is solid and aligns well with our brand guidelines. The user flow feels intuitive and the visual hierarchy is clear.

**Areas for refinement:**
• Color contrast on the secondary buttons
• Spacing between form elements
• Mobile responsive behavior for the navigation

Let's discuss these points in our meeting tomorrow.

Thanks,
Sarah`,
        timestamp: new Date(Date.now() - 60 * 60 * 1000),
        isRead: true,
        isStarred: true,
        isArchived: false,
        hasAttachment: false,
        labels: ["work", "design"]
      },
      {
        id: "3",
        sender: "Alex Liu", 
        senderEmail: "alex.liu@startup.io",
        subject: "Project Timeline Update",
        snippet: "I wanted to update you on the current status of our project timeline and discuss potential adjustments...",
        body: `Hello,

I wanted to update you on the current status of our project timeline and discuss potential adjustments.

We're currently on track with most deliverables, but there are a few areas where we might need to extend deadlines to ensure quality.

**Current status:**
• Phase 1: Complete ✓
• Phase 2: 80% complete 
• Phase 3: Starting next week
• Phase 4: Planning phase

Let me know when you're available to discuss the revised timeline.

Best,
Alex`,
        timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
        isRead: false,
        isStarred: false,
        isArchived: false,
        hasAttachment: false,
        labels: ["projects"]
      },
      {
        id: "4",
        sender: "Maya Johnson",
        senderEmail: "maya.johnson@client.com", 
        subject: "Client Feedback Session",
        snippet: "The client loved the presentation! They want to move forward with phase 2 of the project...",
        body: `Hi team,

The client loved the presentation! They want to move forward with phase 2 of the project.

Their feedback was overwhelmingly positive, especially regarding the user experience improvements and the new feature set.

**Next steps:**
• Finalize the project scope for phase 2
• Update the timeline
• Schedule kickoff meeting
• Prepare resource allocation

I've attached the detailed feedback document for your review.

Regards,
Maya`,
        timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
        isRead: true,
        isStarred: false,
        isArchived: false,
        hasAttachment: true,
        labels: ["clients"]
      },
      {
        id: "5",
        sender: "Ryan Kim",
        senderEmail: "ryan.kim@freelance.com",
        subject: "Invoice #2024-001", 
        snippet: "Please find attached the invoice for the completed work on the dashboard redesign project...",
        body: `Hello,

Please find attached the invoice for the completed work on the dashboard redesign project.

**Project Summary:**
• Dashboard UI/UX redesign
• Frontend implementation
• Testing and optimization
• Documentation

The total amount is $5,500 as per our agreed rate. Payment terms are Net 30.

Thank you for the opportunity to work on this project. I look forward to collaborating again soon.

Best regards,
Ryan Kim`,
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
        isRead: false,
        isStarred: true,
        isArchived: false,
        hasAttachment: true,
        labels: ["invoices"]
      }
    ];

    sampleEmails.forEach(email => {
      this.emails.set(email.id, email);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getEmails(filter?: { isRead?: boolean; isStarred?: boolean; isArchived?: boolean }): Promise<Email[]> {
    let emails = Array.from(this.emails.values());
    
    if (filter) {
      if (filter.isRead !== undefined) {
        emails = emails.filter(email => email.isRead === filter.isRead);
      }
      if (filter.isStarred !== undefined) {
        emails = emails.filter(email => email.isStarred === filter.isStarred);
      }
      if (filter.isArchived !== undefined) {
        emails = emails.filter(email => email.isArchived === filter.isArchived);
      }
    }
    
    return emails.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async getEmail(id: string): Promise<Email | undefined> {
    return this.emails.get(id);
  }

  async createEmail(insertEmail: InsertEmail): Promise<Email> {
    const id = randomUUID();
    const email: Email = {
      ...insertEmail,
      id,
      timestamp: new Date(),
      isRead: insertEmail.isRead ?? false,
      isStarred: insertEmail.isStarred ?? false,
      isArchived: insertEmail.isArchived ?? false,
      hasAttachment: insertEmail.hasAttachment ?? false,
      labels: insertEmail.labels ?? [],
    };
    this.emails.set(id, email);
    return email;
  }

  async updateEmail(id: string, updates: UpdateEmail): Promise<Email | undefined> {
    const email = this.emails.get(id);
    if (!email) return undefined;
    
    const updatedEmail = { ...email, ...updates };
    this.emails.set(id, updatedEmail);
    return updatedEmail;
  }

  async deleteEmail(id: string): Promise<boolean> {
    return this.emails.delete(id);
  }
}

export const storage = new MemStorage();
