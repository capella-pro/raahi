# Overview

This is a modern email inbox application built with React, TypeScript, and Tailwind CSS. The application provides a clean, professional email interface that aims to be cleaner and more polished than traditional email clients like Gmail or Superhuman. It features a three-panel layout with a sidebar for navigation, an email list view, and a detailed email view, along with AI-powered features for enhanced user experience.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**Framework**: React 18 with TypeScript for type safety and modern component patterns
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React hooks (useState, useEffect) combined with TanStack Query for server state
- **Styling**: Tailwind CSS with custom design system using CSS variables
- **UI Components**: Radix UI primitives with custom styling via shadcn/ui
- **Animations**: Framer Motion for smooth transitions and micro-interactions
- **Form Handling**: React Hook Form with Zod validation

**Component Structure**:
- Modular component architecture with clear separation of concerns
- Feature-based organization under `client/src/components/inbox/`
- Reusable UI components in `client/src/components/ui/`
- Custom hooks for responsive behavior and toast notifications

**Design System**:
- CSS custom properties for consistent theming
- Responsive design with mobile-first approach
- Professional color palette with neutral base colors
- Consistent spacing and typography using Tailwind utilities

## Backend Architecture

**Framework**: Express.js with TypeScript for the REST API
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: Centralized schema definitions in `shared/schema.ts` using Drizzle and Zod
- **Storage**: Abstracted storage interface with in-memory implementation for development
- **API Design**: RESTful endpoints for email operations (GET, PATCH, DELETE)

**Development Setup**:
- Vite for fast development builds and hot reload
- Custom Vite middleware integration with Express for seamless development
- Environment-based configuration for database connections

## Data Models

**Email Schema**:
- Core fields: sender, subject, body, timestamp
- Status flags: isRead, isStarred, isArchived, hasAttachment
- Support for labels and categorization
- UUID-based primary keys for scalability

**User Schema**:
- Basic authentication structure (username/password)
- Prepared for future authentication enhancements

## Key Features

**Email Management**:
- Filtering by status (all, unread, starred, archived)
- Email actions (star, archive, delete, mark as read/unread)
- Search functionality with AI-powered suggestions
- Responsive three-panel layout that adapts to mobile

**AI Integration** (Placeholder Implementation):
- Contextual quick reply suggestions based on email content
- AI-powered search suggestions
- Smart email summaries (prepared for future integration)

**User Experience**:
- Smooth animations and transitions
- Mobile-responsive with sheet/drawer patterns
- Toast notifications for user feedback
- Professional, clean design aesthetic

# External Dependencies

## Core Technologies
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver for database connectivity
- **drizzle-orm**: Type-safe ORM for PostgreSQL operations
- **@tanstack/react-query**: Server state management and caching
- **framer-motion**: Animation library for smooth UI transitions

## UI Framework
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework for styling
- **lucide-react**: Icon library for consistent iconography
- **vaul**: Drawer component for mobile interactions

## Development Tools
- **vite**: Fast build tool and development server
- **typescript**: Type safety across the entire application
- **zod**: Runtime type validation and schema definition
- **react-hook-form**: Form state management and validation

## Database
- **PostgreSQL**: Primary database (configured for Neon serverless)
- **drizzle-kit**: Database migrations and schema management
- **connect-pg-simple**: Session store for PostgreSQL (future authentication)

The architecture is designed for scalability and maintainability, with clear separation between client and server code, shared type definitions, and a modular component structure that supports future enhancements like real Gmail API integration or Firebase backend connectivity.