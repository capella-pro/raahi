export interface EmailFilter {
  type: 'all' | 'unread' | 'starred' | 'archived' | 'sent' | 'drafts' | 'spam';
  label: string;
  icon: string;
  count?: number;
}

export interface EmailLabel {
  id: string;
  name: string;
  color: string;
  count: number;
}
