import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { useIsMobile } from "@/hooks/use-mobile";
import { Mail } from "lucide-react";
import type { Email } from "@shared/schema";
import type { EmailFilter } from "@/types/email";
import Sidebar from "@/components/inbox/sidebar";
import EmailList from "@/components/inbox/email-list";
import EmailDetail from "@/components/inbox/email-detail";
import FloatingCompose from "@/components/inbox/floating-compose";
import BottomComposer from "@/components/inbox/bottom-composer";
import { Sheet, SheetContent } from "@/components/ui/sheet";

export default function Inbox() {
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<EmailFilter['type']>('all');
  const [isFloatingComposeOpen, setIsFloatingComposeOpen] = useState(false);
  const [isBottomComposerOpen, setIsBottomComposerOpen] = useState(false);
  const [isMobileDetailOpen, setIsMobileDetailOpen] = useState(false);
  const isMobile = useIsMobile();

  const { data: emails = [], isLoading } = useQuery<Email[]>({
    queryKey: ['/api/emails', `filter=${activeFilter}`],
  });

  const selectedEmail = emails.find(email => email.id === selectedEmailId);

  const handleEmailSelect = (emailId: string) => {
    setSelectedEmailId(emailId);
    if (isMobile) {
      setIsMobileDetailOpen(true);
    }
  };

  const handleCloseMobileDetail = () => {
    setIsMobileDetailOpen(false);
    setSelectedEmailId(null);
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'}}>
      {/* Left Sidebar - Always visible on desktop */}
      <motion.div 
        className="hidden lg:flex"
        initial={{ x: -300, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      >
        <Sidebar 
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
          emails={emails}
        />
      </motion.div>

      {/* Main Panel - Email List */}
      <motion.div 
        className="flex flex-col w-full lg:w-[28rem] bg-transparent"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
      >
        <EmailList
          emails={emails}
          isLoading={isLoading}
          selectedEmailId={selectedEmailId}
          onEmailSelect={handleEmailSelect}
          onComposeOpen={() => setIsFloatingComposeOpen(true)}
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
        />
      </motion.div>

      {/* Right Panel - Email Detail/Conversation */}
      <motion.div 
        className="hidden lg:flex lg:flex-col flex-1 bg-transparent"
        initial={{ x: 300, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
      >
        {selectedEmail ? (
          <EmailDetail
            email={selectedEmail}
            onEmailUpdate={() => {
              // Trigger refetch of emails
            }}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center glass-panel p-8">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
                className="text-white/80"
              >
                <Mail className="w-16 h-16 mx-auto mb-4 text-white/60" />
                <p className="text-xl font-medium mb-2">Select an email to read</p>
                <p className="text-sm text-white/60">Choose an email from the list to view its contents</p>
              </motion.div>
            </div>
          </div>
        )}
      </motion.div>

      {/* Mobile Email Detail Sheet */}
      <Sheet open={isMobileDetailOpen} onOpenChange={handleCloseMobileDetail}>
        <SheetContent side="right" className="w-full p-0">
          {selectedEmail && (
            <EmailDetail
              email={selectedEmail}
              onEmailUpdate={() => {
                // Trigger refetch of emails
              }}
              onClose={handleCloseMobileDetail}
            />
          )}
        </SheetContent>
      </Sheet>

      {/* Floating Glass Composer */}
      <FloatingCompose
        isOpen={isFloatingComposeOpen}
        onClose={() => setIsFloatingComposeOpen(false)}
        replyToEmail={selectedEmail}
      />
    </div>
  );
}
