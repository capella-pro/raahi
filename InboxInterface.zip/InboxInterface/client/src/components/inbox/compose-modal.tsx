import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Paperclip, Image, Smile } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface ComposeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ComposeModal({ isOpen, onClose }: ComposeModalProps) {
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");

  const handleSend = () => {
    // TODO: Implement email sending
    console.log("Sending email:", { to, subject, body });
    onClose();
    // Reset form
    setTo("");
    setSubject("");
    setBody("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    }
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          onKeyDown={handleKeyDown}
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-card rounded-lg shadow-2xl w-full max-w-2xl relative z-10"
            data-testid="compose-modal"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h3 className="text-lg font-semibold text-foreground">Compose Email</h3>
              <button
                onClick={onClose}
                className="p-2 hover:bg-accent rounded-lg transition-colors"
                data-testid="close-compose"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            {/* Form */}
            <div className="p-4 space-y-4">
              <div>
                <Label htmlFor="to" className="block text-sm font-medium text-foreground mb-2">
                  To
                </Label>
                <Input
                  id="to"
                  type="email"
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                  placeholder="recipient@example.com"
                  className="w-full"
                  data-testid="compose-to"
                />
              </div>

              <div>
                <Label htmlFor="subject" className="block text-sm font-medium text-foreground mb-2">
                  Subject
                </Label>
                <Input
                  id="subject"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Email subject"
                  className="w-full"
                  data-testid="compose-subject"
                />
              </div>

              <div>
                <Label htmlFor="body" className="block text-sm font-medium text-foreground mb-2">
                  Message
                </Label>
                <Textarea
                  id="body"
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Write your message..."
                  rows={8}
                  className="w-full resize-none"
                  data-testid="compose-body"
                />
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div className="flex items-center space-x-2">
                  <button
                    className="p-2 hover:bg-accent rounded-lg transition-colors"
                    data-testid="attach-file"
                  >
                    <Paperclip className="w-4 h-4 text-muted-foreground" />
                  </button>
                  <button
                    className="p-2 hover:bg-accent rounded-lg transition-colors"
                    data-testid="attach-image"
                  >
                    <Image className="w-4 h-4 text-muted-foreground" />
                  </button>
                  <button
                    className="p-2 hover:bg-accent rounded-lg transition-colors"
                    data-testid="add-emoji"
                  >
                    <Smile className="w-4 h-4 text-muted-foreground" />
                  </button>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    onClick={onClose}
                    data-testid="cancel-compose"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSend}
                    className="gradient-bg hover:opacity-90 text-white"
                    data-testid="send-email"
                  >
                    Send
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
