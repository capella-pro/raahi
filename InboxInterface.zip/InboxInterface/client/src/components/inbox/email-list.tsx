import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Sparkles, Menu, Star, Mail, Reply, Forward, Archive, Trash2, Paperclip, Filter } from "lucide-react";
import type { Email } from "@shared/schema";
import type { EmailFilter } from "@/types/email";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { formatDistanceToNow } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import Sidebar from "./sidebar";

interface EmailListProps {
  emails: Email[];
  isLoading: boolean;
  selectedEmailId: string | null;
  onEmailSelect: (emailId: string) => void;
  onComposeOpen: () => void;
  activeFilter: EmailFilter['type'];
  onFilterChange: (filter: EmailFilter['type']) => void;
}

export default function EmailList({
  emails,
  isLoading,
  selectedEmailId,
  onEmailSelect,
  onComposeOpen,
  activeFilter,
  onFilterChange
}: EmailListProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAiSuggestions, setShowAiSuggestions] = useState(false);
  const isMobile = useIsMobile();

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getAvatarColor = (name: string) => {
    const colors = [
      'from-blue-400 to-blue-600',
      'from-purple-400 to-purple-600', 
      'from-green-400 to-green-600',
      'from-red-400 to-red-600',
      'from-indigo-400 to-indigo-600',
      'from-pink-400 to-pink-600',
      'from-yellow-400 to-yellow-600',
      'from-teal-400 to-teal-600'
    ];
    const index = name.length % colors.length;
    return colors[index];
  };

  const getPriorityLabel = (email: Email) => {
    if (email.subject.toLowerCase().includes('urgent') || email.body.toLowerCase().includes('urgent')) {
      return 'Urgent';
    }
    if (email.subject.toLowerCase().includes('invoice') || email.body.toLowerCase().includes('payment')) {
      return 'Follow up';
    }
    if (email.subject.toLowerCase().includes('meeting') || email.body.toLowerCase().includes('schedule')) {
      return 'High Priority';
    }
    return 'Normal';
  };

  const getPriorityBadge = (email: Email) => {
    const priority = getPriorityLabel(email);
    switch (priority) {
      case 'Urgent': return 'priority-urgent';
      case 'High Priority': return 'priority-high';
      case 'Follow up': return 'priority-normal';
      default: return 'priority-low';
    }
  };

  const filteredEmails = emails.filter(email => 
    email.sender.toLowerCase().includes(searchQuery.toLowerCase()) ||
    email.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    email.snippet.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const aiSuggestions = [
    "invoices from last week",
    "meetings for tomorrow",
    "unread from clients",
    "attachments this month"
  ];

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Mobile Header */}
      {isMobile && (
        <div className="flex items-center justify-between p-4 border-b border-border">
          <Sheet>
            <SheetTrigger asChild>
              <button
                className="p-2 hover:bg-accent rounded-lg transition-colors"
                data-testid="mobile-menu-trigger"
              >
                <Menu className="w-5 h-5" />
              </button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <Sidebar
                activeFilter={activeFilter}
                onFilterChange={onFilterChange}
                emails={emails}
              />
            </SheetContent>
          </Sheet>
          <h1 className="text-lg font-semibold">Inbox</h1>
          <div className="w-9" /> {/* Spacer for centering */}
        </div>
      )}

      {/* Premium Search Bar */}
      <div className="p-6">
        <div className="glass-panel p-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-4 w-5 h-5 text-white/60" />
            <input
              type="text"
              placeholder="Search emails with AI..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setShowAiSuggestions(true)}
              onBlur={() => setTimeout(() => setShowAiSuggestions(false), 200)}
              className="w-full pl-12 pr-4 py-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 focus:outline-none focus:ring-2 focus:ring-white/30 text-white placeholder-white/60"
              data-testid="search-input"
            />
          </div>
          
          {/* Enhanced Search Filters */}
          <div className="flex items-center gap-2">
            <motion.button 
              className="glass-button px-4 py-2 text-xs rounded-full flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Filter className="w-3 h-3" />
              Unread
            </motion.button>
            <motion.button 
              className="glass-button px-4 py-2 text-xs rounded-full flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Star className="w-3 h-3" />
              Starred
            </motion.button>
            <motion.button 
              className="glass-button px-4 py-2 text-xs rounded-full flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Paperclip className="w-3 h-3" />
              Attachments
            </motion.button>
          </div>
          
          <AnimatePresence>
            {showAiSuggestions && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg z-10"
                data-testid="ai-suggestions"
              >
                <div className="p-2 space-y-1 text-sm">
                  {aiSuggestions.map((suggestion, index) => (
                    <motion.div
                      key={suggestion}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="px-3 py-2 hover:bg-accent rounded cursor-pointer transition-colors"
                      onClick={() => {
                        setSearchQuery(suggestion);
                        setShowAiSuggestions(false);
                      }}
                      data-testid={`ai-suggestion-${index}`}
                    >
                      <Sparkles className="w-4 h-4 inline-block mr-2 text-primary" />
                      {suggestion}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Email List */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {isLoading ? (
          <div className="space-y-1">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="p-4 border-b border-border">
                <div className="flex items-start space-x-3">
                  <Skeleton className="w-10 h-10 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <div className="flex justify-between">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-3 w-8" />
                    </div>
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-full" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <AnimatePresence>
            {filteredEmails.map((email, index) => (
              <motion.div
                key={email.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ delay: index * 0.05 }}
                className={cn(
                  "mx-4 mb-3 glass-card p-5 cursor-pointer",
                  !email.isRead && "border-l-4 border-l-blue-400",
                  selectedEmailId === email.id && "ring-2 ring-white/30"
                )}
                onClick={() => onEmailSelect(email.id)}
                data-testid={`email-item-${email.id}`}
                whileHover={{ scale: 1.02, y: -4 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex items-start space-x-3 group">
                  <div className={cn(
                    "w-10 h-10 rounded-full bg-gradient-to-br flex items-center justify-center text-white text-sm font-semibold flex-shrink-0",
                    getAvatarColor(email.sender)
                  )}>
                    {getInitials(email.sender)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <h4 className={cn(
                          "text-sm truncate",
                          !email.isRead ? "font-semibold text-white" : "font-medium text-white/80"
                        )}>
                          {email.sender}
                        </h4>
                        {/* Enhanced AI Priority Badge */}
                        <motion.span 
                          className={cn(
                            "px-3 py-1 text-xs rounded-full font-medium backdrop-blur-sm border",
                            getPriorityBadge(email)
                          )}
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: 0.2 + index * 0.1 }}
                        >
                          {getPriorityLabel(email)}
                        </motion.span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-white/60">
                          {formatDistanceToNow(new Date(email.timestamp), { addSuffix: false })}
                        </span>
                        {!email.isRead && (
                          <div className="w-2 h-2 bg-primary rounded-full" data-testid="unread-indicator" />
                        )}
                      </div>
                    </div>
                    <p className={cn(
                      "text-sm mb-1 truncate",
                      !email.isRead ? "font-medium text-white" : "text-white/80"
                    )}>
                      {email.subject}
                    </p>
                    <p className="text-sm text-white/60 truncate">
                      {email.snippet}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center space-x-2">
                        {email.hasAttachment && (
                          <Paperclip className="w-3 h-3 text-muted-foreground" />
                        )}
                        {email.isStarred && (
                          <Star className="w-3 h-3 text-yellow-400 fill-current" data-testid="starred-indicator" />
                        )}
                      </div>
                      
                      {/* Glass Action Buttons */}
                      <div className="opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center space-x-2">
                        <motion.button 
                          className="glass-button p-2 rounded-lg" 
                          data-testid="reply-hover"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Reply className="w-4 h-4" />
                        </motion.button>
                        <motion.button 
                          className="glass-button p-2 rounded-lg" 
                          data-testid="forward-hover"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Forward className="w-4 h-4" />
                        </motion.button>
                        <motion.button 
                          className="glass-button p-2 rounded-lg" 
                          data-testid="archive-hover"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Archive className="w-4 h-4" />
                        </motion.button>
                        <motion.button 
                          className="glass-button p-2 rounded-lg" 
                          data-testid="delete-hover"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </motion.button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}

        {!isLoading && filteredEmails.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex-1 flex items-center justify-center p-8"
          >
            <div className="text-center">
              <Mail className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg font-medium text-muted-foreground mb-2">No emails found</p>
              <p className="text-sm text-muted-foreground">
                {searchQuery ? "Try adjusting your search terms" : "Your inbox is empty"}
              </p>
            </div>
          </motion.div>
        )}
      </div>

      {/* Glass Compose Button */}
      <div className="p-6">
        <motion.button
          onClick={onComposeOpen}
          className="w-full glass-button-primary py-4 flex items-center justify-center font-medium text-lg"
          whileHover={{ scale: 1.02, y: -2 }}
          whileTap={{ scale: 0.98 }}
          data-testid="compose-button"
        >
          <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
          </svg>
          Compose Email
        </motion.button>
      </div>
    </div>
  );
}
