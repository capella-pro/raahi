import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Inbox, 
  Mail, 
  Star, 
  Archive, 
  ChevronDown, 
  Send,
  FileText,
  AlertTriangle,
  Trash2,
  Plus,
  Search,
  Sparkles
} from "lucide-react";
import type { Email } from "@shared/schema";
import type { EmailFilter, EmailLabel } from "@/types/email";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeFilter: EmailFilter['type'];
  onFilterChange: (filter: EmailFilter['type']) => void;
  emails: Email[];
}

export default function Sidebar({ activeFilter, onFilterChange, emails }: SidebarProps) {
  const [isLabelsExpanded, setIsLabelsExpanded] = useState(true);

  const folders: EmailFilter[] = [
    { 
      type: 'all', 
      label: 'Inbox', 
      icon: 'inbox',
      count: emails.filter(e => !e.isArchived).length
    },
    { 
      type: 'sent', 
      label: 'Sent', 
      icon: 'send',
      count: 0
    },
    { 
      type: 'drafts', 
      label: 'Drafts', 
      icon: 'file-text',
      count: 0
    },
    { 
      type: 'starred', 
      label: 'Starred', 
      icon: 'star',
      count: emails.filter(e => e.isStarred && !e.isArchived).length
    },
    { 
      type: 'spam', 
      label: 'Spam', 
      icon: 'alert-triangle',
      count: 0
    },
    { 
      type: 'archived', 
      label: 'Trash', 
      icon: 'trash',
      count: emails.filter(e => e.isArchived).length
    },
  ];

  const labels: EmailLabel[] = [
    { id: 'work', name: 'Work', color: 'bg-red-400', count: emails.filter(e => e.labels?.includes('work')).length },
    { id: 'personal', name: 'Personal', color: 'bg-blue-400', count: emails.filter(e => e.labels?.includes('personal')).length },
    { id: 'projects', name: 'Projects', color: 'bg-green-400', count: emails.filter(e => e.labels?.includes('projects')).length },
    { id: 'clients', name: 'Clients', color: 'bg-purple-400', count: emails.filter(e => e.labels?.includes('clients')).length },
    { id: 'invoices', name: 'Invoices', color: 'bg-yellow-400', count: emails.filter(e => e.labels?.includes('invoices')).length },
  ];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'inbox': return <Inbox className="w-4 h-4" />;
      case 'send': return <Send className="w-4 h-4" />;
      case 'file-text': return <FileText className="w-4 h-4" />;
      case 'star': return <Star className="w-4 h-4" />;
      case 'alert-triangle': return <AlertTriangle className="w-4 h-4" />;
      case 'trash': return <Trash2 className="w-4 h-4" />;
      default: return <Inbox className="w-4 h-4" />;
    }
  };

  return (
    <div className="w-64 glass-sidebar flex flex-col">
      {/* Header */}
      <div className="p-6">
        <div className="glass-panel p-4">
          <h1 className="text-xl font-bold text-white">Capella Pro</h1>
          <p className="text-sm text-white/70 mt-1">Premium Email Experience</p>
        </div>
      </div>

      {/* Folders */}
      <div className="px-4 space-y-2">
        <h3 className="text-xs font-semibold text-white/60 uppercase tracking-wider mb-4 px-2">Folders</h3>
        {folders.map((folder) => (
          <motion.button
            key={folder.type}
            onClick={() => onFilterChange(folder.type)}
            className={cn(
              "w-full flex items-center px-4 py-3 rounded-xl text-sm font-medium cursor-pointer transition-all duration-300",
              activeFilter === folder.type
                ? "glass-button-primary text-white"
                : "text-white/70 hover:bg-white/10 hover:text-white"
            )}
            whileHover={{ x: 4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            data-testid={`folder-${folder.type}`}
          >
            {getIcon(folder.icon)}
            <span className="ml-3">{folder.label}</span>
            {folder.count !== undefined && folder.count > 0 && (
              <span className={cn(
                "ml-auto text-xs px-2 py-1 rounded-full backdrop-blur-sm",
                activeFilter === folder.type
                  ? "bg-white/20"
                  : "bg-white/10"
              )}>
                {folder.count}
              </span>
            )}
          </motion.button>
        ))}
      </div>

      {/* Smart AI Folders */}
      <div className="px-4 mt-6 space-y-2">
        <h3 className="text-xs font-semibold text-white/60 uppercase tracking-wider mb-4 px-2 flex items-center">
          <Sparkles className="w-3 h-3 mr-2" />
          Smart Folders
        </h3>
        {[
          { label: 'Important', icon: 'star', count: 3 },
          { label: 'Follow-up Needed', icon: 'clock', count: 2 },
          { label: 'Invoices', icon: 'dollar', count: 1 },
          { label: 'Clients', icon: 'users', count: 5 }
        ].map((smartFolder) => (
          <motion.button
            key={smartFolder.label}
            className="w-full flex items-center px-4 py-3 rounded-xl text-sm font-medium cursor-pointer transition-all duration-300 text-white/70 hover:bg-white/10 hover:text-white"
            whileHover={{ x: 4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            data-testid={`smart-folder-${smartFolder.label.toLowerCase().replace(' ', '-')}`}
          >
            <div className="w-2 h-2 rounded-full bg-gradient-to-r from-blue-400 to-purple-500 mr-4"></div>
            <span>{smartFolder.label}</span>
            <span className="ml-auto text-xs px-2 py-1 rounded-full bg-white/10">
              {smartFolder.count}
            </span>
          </motion.button>
        ))}
      </div>

      {/* Enhanced Search */}
      <div className="px-4 mt-6">
        <div className="glass-panel p-3">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-white/60" />
            <input
              type="text"
              placeholder="AI-powered search..."
              className="w-full pl-10 pr-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20 focus:outline-none focus:ring-2 focus:ring-white/30 text-white placeholder-white/60 text-sm"
            />
          </div>
        </div>
      </div>

      {/* Labels Section */}
      <div className="px-4 py-4">
        <button
          onClick={() => setIsLabelsExpanded(!isLabelsExpanded)}
          className="flex items-center justify-between w-full py-2 text-sm font-medium text-white/70 hover:text-white transition-colors"
          data-testid="toggle-labels"
        >
          <span>Labels</span>
          <motion.div
            animate={{ rotate: isLabelsExpanded ? 0 : -90 }}
            transition={{ duration: 0.2 }}
          >
            <ChevronDown className="w-4 h-4" />
          </motion.div>
        </button>

        <motion.div
          initial={false}
          animate={{ 
            height: isLabelsExpanded ? "auto" : 0,
            opacity: isLabelsExpanded ? 1 : 0
          }}
          transition={{ duration: 0.2 }}
          className="overflow-hidden"
        >
          <div className="space-y-1 text-sm">
            {labels.map((label) => (
              <motion.div
                key={label.id}
                className="flex items-center px-2 py-1 rounded cursor-pointer hover:bg-accent transition-colors group"
                whileHover={{ x: 2 }}
                data-testid={`label-${label.id}`}
              >
                <div className={cn("w-3 h-3 rounded-full mr-3", label.color)}></div>
                <span className="text-white/70 group-hover:text-white transition-colors">{label.name}</span>
                {label.count > 0 && (
                  <span className="ml-auto text-xs text-white/60">{label.count}</span>
                )}
              </motion.div>
            ))}
            <motion.button
              className="flex items-center px-2 py-1 rounded cursor-pointer hover:bg-accent transition-colors text-muted-foreground hover:text-foreground w-full"
              whileHover={{ x: 2 }}
              data-testid="add-label"
            >
              <Plus className="w-3 h-3 mr-3" />
              <span className="text-sm text-white/70">Add Label</span>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
