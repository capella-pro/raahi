import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, 
  Paperclip, 
  Image, 
  Smile, 
  Send,
  Sparkles,
  Bold,
  Italic,
  Maximize2,
  Minimize2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface FloatingComposeProps {
  isOpen: boolean;
  onClose: () => void;
  replyToEmail?: any;
}

export default function FloatingCompose({ isOpen, onClose, replyToEmail }: FloatingComposeProps) {
  const [to, setTo] = useState(replyToEmail?.senderEmail || "");
  const [subject, setSubject] = useState(replyToEmail ? `Re: ${replyToEmail.subject}` : "");
  const [body, setBody] = useState("");
  const [isExpanded, setIsExpanded] = useState(false);
  const [showAiAssist, setShowAiAssist] = useState(false);

  const handleSend = () => {
    console.log("Sending email:", { to, subject, body });
    onClose();
    // Reset form
    setTo("");
    setSubject("");
    setBody("");
  };

  const handleAiAssist = () => {
    if (!subject) {
      setSubject("AI-Generated: Follow up on our discussion");
    }
    if (!body) {
      setBody("Hi there,\\n\\nI wanted to follow up on our recent conversation. Please let me know if you have any questions or if there's anything specific you'd like to discuss.\\n\\nBest regards");
    }
    setShowAiAssist(false);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4"
        style={{ background: 'rgba(0, 0, 0, 0.4)', backdropFilter: 'blur(8px)' }}
      >
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0"
          onClick={onClose}
        />

        {/* Floating Glass Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 50 }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          className={`glass-compose-modal relative z-10 w-full ${isExpanded ? 'max-w-4xl h-[80vh]' : 'max-w-2xl'}`}
          data-testid="floating-compose-modal"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-white/10">
            <div className="flex items-center gap-3">
              <h3 className="text-xl font-semibold text-white">
                {replyToEmail ? "Reply" : "Compose Email"}
              </h3>
              {replyToEmail && (
                <span className="text-sm text-white/70 bg-white/10 px-3 py-1 rounded-full">
                  to {replyToEmail.sender}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <motion.button
                onClick={() => setIsExpanded(!isExpanded)}
                className="glass-button p-3"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                data-testid="expand-floating-composer"
              >
                {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </motion.button>
              <motion.button
                onClick={onClose}
                className="glass-button p-3"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                data-testid="close-floating-composer"
              >
                <X className="w-4 h-4" />
              </motion.button>
            </div>
          </div>

          {/* Form Content */}
          <div className={`p-6 ${isExpanded ? 'h-full flex flex-col' : ''}`}>
            <div className="space-y-4 flex-1">
              {/* To and Subject */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="compose-to-floating" className="block text-sm font-medium text-white/80 mb-2">
                    To
                  </Label>
                  <Input
                    id="compose-to-floating"
                    type="email"
                    value={to}
                    onChange={(e) => setTo(e.target.value)}
                    placeholder="recipient@example.com"
                    className="bg-white/10 border-white/20 text-white placeholder-white/50 focus:ring-white/30"
                    data-testid="compose-to-floating"
                  />
                </div>
                <div>
                  <Label htmlFor="compose-subject-floating" className="block text-sm font-medium text-white/80 mb-2">
                    Subject
                  </Label>
                  <Input
                    id="compose-subject-floating"
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Email subject"
                    className="bg-white/10 border-white/20 text-white placeholder-white/50 focus:ring-white/30"
                    data-testid="compose-subject-floating"
                  />
                </div>
              </div>

              {/* Minimalist Toolbar */}
              <div className="flex items-center justify-between py-2 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <motion.button
                    className="glass-button p-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    data-testid="bold-text"
                  >
                    <Bold className="w-4 h-4" />
                  </motion.button>
                  <motion.button
                    className="glass-button p-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    data-testid="italic-text"
                  >
                    <Italic className="w-4 h-4" />
                  </motion.button>
                  <motion.button
                    className="glass-button p-2"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    data-testid="attach-file-floating"
                  >
                    <Paperclip className="w-4 h-4" />
                  </motion.button>
                </div>
                
                <motion.button
                  onClick={() => setShowAiAssist(!showAiAssist)}
                  className="glass-button-primary px-4 py-2 flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  data-testid="ai-assist-floating"
                >
                  <Sparkles className="w-4 h-4" />
                  AI Assist
                </motion.button>
              </div>

              {/* AI Assist Panel */}
              <AnimatePresence>
                {showAiAssist && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="glass-panel p-4"
                    data-testid="ai-assist-panel-floating"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <Sparkles className="w-4 h-4 text-blue-400 mr-2" />
                        <span className="text-sm font-medium text-white">AI Assistant</span>
                      </div>
                      <motion.button
                        onClick={handleAiAssist}
                        className="glass-button-primary px-3 py-1 text-xs"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        Generate
                      </motion.button>
                    </div>
                    <p className="text-xs text-white/70">
                      Click Generate to auto-create a professional subject line and email body based on the context.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Message Body */}
              <div className="flex-1">
                <Label htmlFor="compose-body-floating" className="block text-sm font-medium text-white/80 mb-2">
                  Message
                </Label>
                <Textarea
                  id="compose-body-floating"
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Write your message..."
                  rows={isExpanded ? 12 : 6}
                  className="w-full bg-white/10 border-white/20 text-white placeholder-white/50 focus:ring-white/30 resize-none"
                  data-testid="compose-body-floating"
                />
              </div>
            </div>

            {/* Footer Actions */}
            <div className="flex items-center justify-between pt-6 border-t border-white/10 mt-6">
              <div className="flex items-center space-x-2">
                <motion.button
                  className="glass-button p-3"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  data-testid="attach-image-floating"
                >
                  <Image className="w-4 h-4" />
                </motion.button>
                <motion.button
                  className="glass-button p-3"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  data-testid="add-emoji-floating"
                >
                  <Smile className="w-4 h-4" />
                </motion.button>
              </div>
              
              <div className="flex items-center space-x-3">
                <Button
                  variant="ghost"
                  onClick={onClose}
                  className="text-white/70 hover:text-white hover:bg-white/10"
                  data-testid="cancel-compose-floating"
                >
                  Cancel
                </Button>
                <motion.button
                  onClick={handleSend}
                  className="glass-button-primary px-6 py-3 flex items-center gap-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  data-testid="send-email-floating"
                >
                  <Send className="w-4 h-4" />
                  Send
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}