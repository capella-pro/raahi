import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import type { Email } from "@shared/schema";

interface AIQuickRepliesProps {
  email: Email;
}

export default function AIQuickReplies({ email }: AIQuickRepliesProps) {
  const generateQuickReplies = (email: Email) => {
    const subject = email.subject.toLowerCase();
    const body = email.body.toLowerCase();

    // Generate contextual replies based on email content
    if (subject.includes('meeting') || body.includes('schedule')) {
      return [
        "Sounds good! I'm available Tuesday 2-4 PM",
        "Let's schedule a call to discuss", 
        "I'll check my calendar and get back to you"
      ];
    } else if (subject.includes('invoice') || body.includes('payment')) {
      return [
        "Payment will be processed within 2 business days",
        "Invoice received, thank you",
        "I'll forward this to our accounting team"
      ];
    } else if (subject.includes('feedback') || subject.includes('review')) {
      return [
        "Thank you for the feedback!",
        "I'll incorporate these changes",
        "Let's discuss this further"
      ];
    } else if (subject.includes('project') || subject.includes('timeline')) {
      return [
        "I'll review and update you",
        "Thanks for the update",
        "Let's align on next steps"
      ];
    } else {
      return [
        "Thank you for reaching out",
        "I'll get back to you soon",
        "Let's discuss this further"
      ];
    }
  };

  const quickReplies = generateQuickReplies(email);

  const handleQuickReply = (reply: string) => {
    // Trigger floating compose with pre-filled reply
    window.dispatchEvent(new CustomEvent('openReplyWithText', { 
      detail: { email, replyText: reply } 
    }));
    console.log('Quick reply selected:', reply);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="glass-panel p-4"
      data-testid="ai-quick-replies"
    >
      <div className="flex items-center mb-4">
        <Sparkles className="w-5 h-5 text-blue-400 mr-2" />
        <span className="text-lg font-medium text-white">Quick AI Replies</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {quickReplies.map((reply, index) => (
          <motion.button
            key={index}
            onClick={() => handleQuickReply(reply)}
            className="glass-button-primary p-4 text-sm rounded-xl text-left transition-all duration-300 hover:scale-105"
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 + index * 0.1 }}
            data-testid={`quick-reply-${index}`}
          >
            <div className="flex items-start">
              <div className="w-2 h-2 rounded-full bg-white/60 mr-3 mt-2 flex-shrink-0"></div>
              <span className="text-white leading-relaxed">{reply}</span>
            </div>
          </motion.button>
        ))}
      </div>
      
      {/* Thread View Indicator */}
      <motion.div
        className="mt-4 pt-4 border-t border-white/10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <div className="flex items-center justify-between text-sm text-white/70">
          <span>This email • Thread of 1</span>
          <button className="glass-button px-3 py-1 text-xs hover:scale-105 transition-transform">
            View Thread
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
