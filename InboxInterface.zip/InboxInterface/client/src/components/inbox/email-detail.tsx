import { useState } from "react";
import { motion } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Star, 
  Archive, 
  Trash2, 
  Reply, 
  Forward, 
  Sparkles,
  X,
  ArrowLeft,
  Clock,
  DollarSign,
  Users
} from "lucide-react";
import type { Email } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import AIQuickReplies from "./ai-quick-replies";

interface EmailDetailProps {
  email: Email;
  onEmailUpdate: () => void;
  onClose?: () => void;
}

export default function EmailDetail({ email, onEmailUpdate, onClose }: EmailDetailProps) {
  const [isStarring, setIsStarring] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const isMobile = useIsMobile();

  const updateEmailMutation = useMutation({
    mutationFn: async (updates: Partial<Email>) => {
      const response = await apiRequest('PATCH', `/api/emails/${email.id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/emails'] });
      onEmailUpdate();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update email",
        variant: "destructive",
      });
    },
  });

  const deleteEmailMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', `/api/emails/${email.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/emails'] });
      toast({
        title: "Email deleted",
        description: "The email has been moved to trash",
      });
      if (onClose) onClose();
    },
    onError: () => {
      toast({
        title: "Error", 
        description: "Failed to delete email",
        variant: "destructive",
      });
    },
  });

  const handleStar = async () => {
    setIsStarring(true);
    updateEmailMutation.mutate({ isStarred: !email.isStarred });
    setTimeout(() => setIsStarring(false), 200);
  };

  const handleMarkAsRead = () => {
    if (!email.isRead) {
      updateEmailMutation.mutate({ isRead: true });
    }
  };

  const handleArchive = () => {
    updateEmailMutation.mutate({ isArchived: true });
    if (onClose) onClose();
  };

  const handleDelete = () => {
    deleteEmailMutation.mutate();
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getAvatarColor = (name: string) => {
    const colors = [
      'from-blue-400 to-blue-600',
      'from-purple-400 to-purple-600',
      'from-green-400 to-green-600', 
      'from-red-400 to-red-600',
      'from-indigo-400 to-indigo-600',
      'from-pink-400 to-pink-600',
      'from-yellow-400 to-yellow-600',
      'from-teal-400 to-teal-600'
    ];
    const index = email.sender.length % colors.length;
    return colors[index];
  };

  // AI helper functions
  const getSentiment = (email: Email) => {
    const text = (email.subject + ' ' + email.body).toLowerCase();
    if (text.includes('urgent') || text.includes('asap') || text.includes('immediate')) {
      return 'Urgent';
    }
    if (text.includes('thank') || text.includes('great') || text.includes('excellent')) {
      return 'Positive';
    }
    return 'Neutral';
  };

  const getFollowUpSuggestions = (email: Email) => {
    const suggestions = [];
    if (email.subject.toLowerCase().includes('meeting')) {
      suggestions.push('Schedule Meeting', 'Check Calendar');
    }
    if (email.subject.toLowerCase().includes('invoice') || email.body.toLowerCase().includes('payment')) {
      suggestions.push('Process Payment', 'Forward to Accounting');
    }
    if (email.body.toLowerCase().includes('deadline') || email.body.toLowerCase().includes('due')) {
      suggestions.push('Set Reminder', 'Add to Calendar');
    }
    return suggestions.length > 0 ? suggestions : ['Reply', 'Archive'];
  };

  // Mark as read when component mounts
  useState(() => {
    handleMarkAsRead();
  });

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex flex-col h-full bg-transparent"
    >
      {/* Glass Back Button - Always visible */}
      <div className="p-6">
        <motion.button
          onClick={onClose}
          className="glass-button p-3 mb-4 flex items-center gap-2"
          whileHover={{ scale: 1.05, x: -2 }}
          whileTap={{ scale: 0.95 }}
          data-testid="back-button"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Inbox</span>
        </motion.button>
      </div>

      {/* Glass Email Header */}
      <div className="px-6 pb-6">
        <motion.div 
          className="glass-panel p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-start space-x-4">
              <motion.div 
                className={`w-14 h-14 rounded-full bg-gradient-to-br ${getAvatarColor(email.sender)} flex items-center justify-center text-white text-lg font-semibold`}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.4, type: "spring", stiffness: 200 }}
              >
                {getInitials(email.sender)}
              </motion.div>
              <div>
                <h2 className="text-xl font-semibold text-white mb-2">{email.subject}</h2>
                <div className="flex items-center space-x-2 text-sm text-white/70">
                  <span>{email.sender}</span>
                  <span>•</span>
                  <span>{email.senderEmail}</span>
                  <span>•</span>
                  <span>{formatDistanceToNow(new Date(email.timestamp), { addSuffix: true })}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <motion.button
                onClick={handleStar}
                className="glass-button p-3"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={isStarring}
                data-testid="star-button"
              >
                <Star 
                  className={`w-5 h-5 ${email.isStarred ? 'text-yellow-400 fill-current' : 'text-white/70'}`} 
                />
              </motion.button>
              <motion.button
                onClick={handleArchive}
                className="glass-button p-3"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                data-testid="archive-button"
              >
                <Archive className="w-5 h-5 text-white/70" />
              </motion.button>
              <motion.button
                onClick={handleDelete}
                className="glass-button p-3"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                data-testid="delete-button"
              >
                <Trash2 className="w-5 h-5 text-white/70" />
              </motion.button>
              <div className="w-px h-6 bg-white/20 mx-2"></div>
              <motion.button
                className="glass-button-primary p-3"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                data-testid="reply-button"
                onClick={() => window.dispatchEvent(new CustomEvent('openReply', { detail: email }))}
              >
                <Reply className="w-5 h-5" />
              </motion.button>
              <motion.button
                className="glass-button p-3"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                data-testid="forward-button"
              >
                <Forward className="w-5 h-5 text-white/70" />
              </motion.button>
            </div>
          </div>

        {/* Enhanced Glass AI Summary with Sentiment */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass-panel p-4 mb-4"
          data-testid="ai-summary"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <Sparkles className="w-4 h-4 text-blue-400 mr-2" />
              <span className="text-sm font-medium text-white">AI Analysis</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 text-xs rounded-full font-medium backdrop-blur-sm ${
                getSentiment(email) === 'Positive' ? 'bg-green-500/20 text-green-300 border border-green-500/30' :
                getSentiment(email) === 'Urgent' ? 'bg-red-500/20 text-red-300 border border-red-500/30' :
                'bg-gray-500/20 text-gray-300 border border-gray-500/30'
              }`}>
                {getSentiment(email)}
              </span>
            </div>
          </div>
          <p className="text-sm text-white/70 mb-3">
            {email.sender} is discussing {email.subject.toLowerCase()}. 
            {email.hasAttachment && " The email includes an attachment."}
            {email.body.includes("meeting") && " A meeting is being proposed."}
            {email.body.includes("budget") && " Budget-related content is included."}
            {email.body.includes("project") && " Project updates are mentioned."}
          </p>
          
          {/* Follow-up Suggestions */}
          <div className="space-y-2">
            <p className="text-xs font-medium text-blue-400">AI Suggestions:</p>
            <div className="flex flex-wrap gap-2">
              {getFollowUpSuggestions(email).map((suggestion, index) => (
                <button
                  key={index}
                  className="px-3 py-1 text-xs glass-button rounded-lg transition-colors"
                  data-testid={`followup-${index}`}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        </motion.div>
        </motion.div>
      </div>

      {/* Glass Email Body */}
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 pb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="glass-panel p-6 mb-6"
        >
          <div
            className="text-white/90 whitespace-pre-wrap leading-relaxed"
            dangerouslySetInnerHTML={{
              __html: email.body
                .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white font-semibold">$1</strong>')
                .replace(/•/g, '•')
                .replace(/\n\n/g, '</p><p class="mb-4">')
                .replace(/^(.*)$/gm, '<p class="mb-4">$1</p>')
            }}
          />
        </motion.div>

        {/* Enhanced AI Quick Replies */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <AIQuickReplies email={email} />
        </motion.div>
      </div>
    </motion.div>
  );
}
