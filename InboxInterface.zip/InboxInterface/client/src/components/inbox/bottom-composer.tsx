import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, 
  Paperclip, 
  Image, 
  Smile, 
  Send,
  Sparkles,
  ChevronUp,
  ChevronDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface BottomComposerProps {
  isOpen: boolean;
  onClose: () => void;
  replyToEmail?: any;
}

export default function BottomComposer({ isOpen, onClose, replyToEmail }: BottomComposerProps) {
  const [to, setTo] = useState(replyToEmail?.senderEmail || "");
  const [subject, setSubject] = useState(replyToEmail ? `Re: ${replyToEmail.subject}` : "");
  const [body, setBody] = useState("");
  const [isExpanded, setIsExpanded] = useState(false);
  const [showAiSuggestions, setShowAiSuggestions] = useState(false);

  const handleSend = () => {
    console.log("Sending email:", { to, subject, body });
    onClose();
    // Reset form
    setTo("");
    setSubject("");
    setBody("");
  };

  const aiSuggestions = [
    "Thank you for reaching out. I'll review this and get back to you shortly.",
    "I appreciate your email. Let's schedule a call to discuss this further.",
    "Thanks for the update. I'll incorporate your feedback and send a revised version."
  ];

  const aiToneAdjustments = [
    { label: "Professional", description: "Make it more formal and business-appropriate" },
    { label: "Friendly", description: "Add warmth and conversational tone" },
    { label: "Concise", description: "Shorten and make more direct" },
    { label: "Detailed", description: "Expand with more context and explanation" }
  ];

  const handleAiSuggestion = (suggestion: string) => {
    setBody(suggestion);
    setShowAiSuggestions(false);
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ y: "100%" }}
      animate={{ y: 0 }}
      exit={{ y: "100%" }}
      transition={{ type: "spring", damping: 30, stiffness: 300 }}
      className="fixed bottom-0 left-0 right-0 bg-card border-t border-border shadow-2xl z-50"
      data-testid="bottom-composer"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-semibold text-foreground">
            {replyToEmail ? "Reply" : "Compose Email"}
          </h3>
          {replyToEmail && (
            <span className="text-sm text-muted-foreground">
              to {replyToEmail.sender}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 hover:bg-accent rounded-lg transition-colors"
            data-testid="expand-composer"
          >
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
          <button
            onClick={onClose}
            className="p-2 hover:bg-accent rounded-lg transition-colors"
            data-testid="close-bottom-composer"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Composer Content */}
      <div className={`transition-all duration-300 ${isExpanded ? 'h-96' : 'h-48'}`}>
        <div className="p-4 h-full flex flex-col">
          {/* To and Subject - Only show when expanded */}
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-3 mb-4"
              >
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="compose-to" className="block text-sm font-medium text-foreground mb-2">
                      To
                    </Label>
                    <Input
                      id="compose-to"
                      type="email"
                      value={to}
                      onChange={(e) => setTo(e.target.value)}
                      placeholder="recipient@example.com"
                      data-testid="compose-to-bottom"
                    />
                  </div>
                  <div>
                    <Label htmlFor="compose-subject" className="block text-sm font-medium text-foreground mb-2">
                      Subject
                    </Label>
                    <Input
                      id="compose-subject"
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="Email subject"
                      data-testid="compose-subject-bottom"
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Message Body */}
          <div className="flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <Label htmlFor="compose-body" className="text-sm font-medium text-foreground">
                Message
              </Label>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAiSuggestions(!showAiSuggestions)}
                  className="flex items-center gap-1 px-2 py-1 text-xs bg-primary/10 hover:bg-primary/20 text-primary rounded transition-colors"
                  data-testid="ai-assistance"
                >
                  <Sparkles className="w-3 h-3" />
                  AI Assist
                </button>
              </div>
            </div>
            
            <Textarea
              id="compose-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Write your message..."
              className="flex-1 resize-none min-h-[80px]"
              data-testid="compose-body-bottom"
            />

            {/* AI Suggestions Panel */}
            <AnimatePresence>
              {showAiSuggestions && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="mt-3 p-3 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg"
                  data-testid="ai-suggestions-panel"
                >
                  <div className="flex items-center mb-3">
                    <Sparkles className="w-4 h-4 text-primary mr-2" />
                    <span className="text-sm font-medium text-primary">AI Assistance</span>
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Quick Replies:</p>
                      <div className="flex flex-wrap gap-1">
                        {aiSuggestions.map((suggestion, index) => (
                          <button
                            key={index}
                            onClick={() => handleAiSuggestion(suggestion)}
                            className="px-2 py-1 text-xs bg-white hover:bg-accent rounded border transition-colors"
                            data-testid={`ai-suggestion-${index}`}
                          >
                            {suggestion.slice(0, 30)}...
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Tone Adjustments:</p>
                      <div className="flex flex-wrap gap-1">
                        {aiToneAdjustments.map((tone, index) => (
                          <button
                            key={index}
                            className="px-2 py-1 text-xs bg-white hover:bg-accent rounded border transition-colors"
                            data-testid={`tone-${tone.label.toLowerCase()}`}
                          >
                            {tone.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex items-center space-x-2">
              <button
                className="p-2 hover:bg-accent rounded-lg transition-colors"
                data-testid="attach-file-bottom"
              >
                <Paperclip className="w-4 h-4 text-muted-foreground" />
              </button>
              <button
                className="p-2 hover:bg-accent rounded-lg transition-colors"
                data-testid="attach-image-bottom"
              >
                <Image className="w-4 h-4 text-muted-foreground" />
              </button>
              <button
                className="p-2 hover:bg-accent rounded-lg transition-colors"
                data-testid="add-emoji-bottom"
              >
                <Smile className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                onClick={onClose}
                data-testid="cancel-compose-bottom"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSend}
                className="capella-button flex items-center gap-2"
                data-testid="send-email-bottom"
              >
                <Send className="w-4 h-4" />
                Send
              </Button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}